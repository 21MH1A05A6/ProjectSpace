
const user = require("../models/user");


const addUser = async (req, res, next) => {
  console.log("write ur functionality here")
 
}

exports.addUser = addUser;

// const adduser = async(req,res,next)=>{
//   console.log(req.body.form1data);
//   const{email,password}=req.body.form1data;
//       const user1= new user({
//           email,
//           password
//       })
      
//       user1.save();
     
// }
// exports.adduser = adduser;
