const mongoose = require("mongoose");
const DomainSchema = mongoose.Schema({
  domain: {
    type: String,
    required: true
  },
  sub_domain: {
    type: String,
    required: true
  },
  domain_expiry: {
    type: String,
    required: true
  },
  auto_renewal: {
    type: String,
    required: true
  },
  ssl_type: {
    type: String,
    required: true
  },
  ssl_expiry: {
    type: String,
    required: true
  },
},

{ 
  collection: 'domains' 
});

// export model user with ServerformSchema
module.exports = mongoose.model("domains",DomainSchema);